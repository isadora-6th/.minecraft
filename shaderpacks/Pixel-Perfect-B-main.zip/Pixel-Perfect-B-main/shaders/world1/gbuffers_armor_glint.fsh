#version 330
#define DIM_END

#include "/program/gbuffers/armor_glint.fsh"